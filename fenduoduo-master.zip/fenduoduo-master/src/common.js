const pkg = require('../package.json')

exports.pkg = pkg
