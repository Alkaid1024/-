if (/ks\.wjx\.top/.test(window.location.href)) {
  require('./wjx')
}
