<div align="center">

![Logo designed by ZhangZisu](https://i.loli.net/2020/02/27/C1A5PGZfKB7gJ4Q.png)

# 分多多
> 任何借口都无法掩饰停课不停学形式主义的实质与加剧内卷的后果

</div>

[greasyfork](https://greasyfork.org/zh-CN/scripts/396937-fenduoduo)

## 功能
- 问卷星
  1. 允许复制粘贴
  2. 强制单页显示
  3. 答案导入导出
  4. 云端答案共享

## 使用
请安装油猴(Tampermonkey)并打开上面greasyfork的链接安装本脚本
